import requests
base = "https://images-ddg.pages.dev"

try:
    DB = requests.get("{}/list.json".format(base), verify=False).json()
except:
    DB = {}

def getIMG(id, type="white"):
    global DB

    if DB == {}:
        try:
            DB = requests.get("{}/list.json".format(base), verify=False).json()
        except:
            DB = {}

    try:
        path = DB[id]['urls'][type]
    except KeyError:
        path = DB['not-found']['urls'][type]
    return "{base}/{path}".format(base=base, path=path)
