# repository.lekma
lekma's repository for Kodi addons.

Download the latest version from [here](https://github.com/lekma/repository.lekma/releases/).
