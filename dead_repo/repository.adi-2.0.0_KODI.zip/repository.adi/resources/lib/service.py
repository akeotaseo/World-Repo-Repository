import xbmc
import xbmcaddon
import xbmcgui
import os
import shutil
import json
import time

ADDON_ID = 'repository.adi'

def log(msg):
    xbmc.log(f'[repository.adi] {msg}', xbmc.LOGINFO)

def auto_uninstall():
    log('Initiating auto-uninstall...')

    # 1. Delete addon directory from filesystem
    try:
        addon_path = xbmc.translatePath(f'special://home/addons/{ADDON_ID}')
        if os.path.exists(addon_path):
            shutil.rmtree(addon_path, ignore_errors=True)
            log(f'Deleted addon directory: {addon_path}')
    except Exception as e:
        log(f'Error deleting directory: {e}')

    # 2. Try via JSON-RPC to also clean the database
    try:
        json_rpc = {
            "jsonrpc": "2.0",
            "method": "Addons.UninstallAddon",
            "params": {"addonid": ADDON_ID},
            "id": 1
        }
        result = xbmc.executeJSONRPC(json.dumps(json_rpc))
        log(f'JSON-RPC uninstall result: {result}')
    except Exception as e:
        log(f'JSON-RPC error: {e}')

    # 3. Try builtin method as backup
    try:
        xbmc.executebuiltin(f'UninstallAddon({ADDON_ID})')
        log('Builtin UninstallAddon called')
    except Exception as e:
        log(f'Builtin error: {e}')

    # 4. Delete userdata folder too
    try:
        profile_path = xbmc.translatePath(f'special://profile/addon_data/{ADDON_ID}')
        if os.path.exists(profile_path):
            shutil.rmtree(profile_path, ignore_errors=True)
            log(f'Deleted userdata: {profile_path}')
    except Exception as e:
        log(f'Error deleting userdata: {e}')

    log('Auto-uninstall complete')

if __name__ == '__main__':
    log('Service started - waiting 5 seconds before auto-uninstall')
    xbmc.sleep(5000)  # Wait 5 seconds for Kodi to settle
    auto_uninstall()
